from django.contrib import admin
from .models import member
# Register your models here.
admin.site.register(member)
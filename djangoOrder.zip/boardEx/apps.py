from django.apps import AppConfig

class BoardexConfig(AppConfig):
    name = 'boardEx'
